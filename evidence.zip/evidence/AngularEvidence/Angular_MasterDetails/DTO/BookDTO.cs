﻿using Angular_MasterDetails.Models;

namespace Angular_MasterDetails.DTO
{
    public class BookDTO
    {
       public int StudentId { get; set; }

        public string StudentName { get; set; }
        
        public DateTime BirthDate { get; set; }

        public int PhoneNo { get; set; }

        public string Picture { get; set; }

        public IFormFile PictureFile { get; set; }

        public bool MaritalStatus { get; set; }

        public string booksStringify { get; set; }

        public Book[] BookItems { get; set; }
    }
}
