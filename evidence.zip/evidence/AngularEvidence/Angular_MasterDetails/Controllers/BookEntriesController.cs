﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Angular_MasterDetails.Models;
using Angular_MasterDetails.DTO;
using Newtonsoft.Json;

namespace Angular_MasterDetails.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookEntriesController : ControllerBase
    {
        private readonly BookDbContext _context;
        private readonly IWebHostEnvironment _env;

        public BookEntriesController(BookDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            this._env = env;
        }

        [HttpGet]
        [Route("GetBooks")]
        public async Task<ActionResult<IEnumerable<Book>>> GetBooks()
        {
            return await _context.Books.ToListAsync();
        }
        
        [HttpGet]
        [Route("GetStudents")]
        public async Task<ActionResult<IEnumerable<Student>>> GetStudents()
        {
            return await _context.Students.ToListAsync();
        } 
       

        // GET: api/BookingEntries
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BookDTO>>> GetBookEntries()
        {
            List<BookDTO> bookingBooks = new List<BookDTO>();

            var allStudents = _context.Students.ToList();
            foreach (var student in allStudents)
            {
                var bookList = _context.BookEntries.Where(x => x.StudentId == student.StudentId).Select(x => new Book { BookId = x.BookId }).ToList();
                bookingBooks.Add(new BookDTO
                {
                    StudentId = student.StudentId,
                    StudentName = student.StudentName,
                    BirthDate = student.BirthDate,
                    PhoneNo = student.PhoneNo,
                    MaritalStatus = student.MaritalStatus,
                    Picture = student.Picture,
                    BookItems = bookList.ToArray()
                });
            }

         
            return bookingBooks;
        }


        // POST: api/BookEntries
        [HttpPost]
        public async Task<ActionResult<BookEntry>> PostBookEntry([FromForm] BookDTO bookDTO)
        {

            var bookItems = JsonConvert.DeserializeObject<Book[]>(bookDTO.booksStringify);

            Student student = new Student
            {
                StudentName = bookDTO.StudentName,
                BirthDate = bookDTO.BirthDate,
                PhoneNo = bookDTO.PhoneNo,
                MaritalStatus = bookDTO.MaritalStatus
            };

            if (bookDTO.PictureFile != null)
            {
                var webroot = _env.WebRootPath;
                var fileName = Guid.NewGuid().ToString() + Path.GetExtension(bookDTO.PictureFile.FileName);
                var filePath = Path.Combine(webroot, "Images", fileName);

                FileStream fileStream = new FileStream(filePath, FileMode.Create);
                await bookDTO.PictureFile.CopyToAsync(fileStream);
                await fileStream.FlushAsync();
                fileStream.Close();
                student.Picture = fileName;
            }

            foreach (var item in bookItems)
            {
                var bookingEntry = new BookEntry
                {
                    Student = student,
                    StudentId = student.StudentId,
                    BookId = item.BookId
                };
                _context.Add(bookingEntry);
            }

            await _context.SaveChangesAsync();

            return Ok(student);
        }

    }
}
