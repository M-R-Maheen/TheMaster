import { Book } from '../../models/book';
import { BookingBook } from '../../models/booking-book';  // BookingSpot
import { DataService } from './../../services/data.service';
import { Component } from '@angular/core';

@Component({
  selector: 'app-master-view',
  templateUrl: './master-view.component.html',
  styleUrls: ['./master-view.component.css']
})
export class MasterViewComponent {

  bookList : Book[] = [];  //Spot
  bookingList : BookingBook[] = [];  //BookingSpot

  constructor(
    private dataSvc : DataService
  ){}

  ngOnInit(): void {

    this.dataSvc.getBookList().subscribe(x => {
      this.bookList = x; //spotList
    });
    this.dataSvc.getBookEntries().subscribe(x => {
      this.bookingList = x;
    });
  }

  getBookName(id : any){
    let data = this.bookList.find(x => x.bookId == id); //spotList
    return data?data.bookName : '';
  }


}
