import { Book } from '../../models/book';  //Spot
import { DataService } from './../../services/data.service';
import { Component } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-master',
  templateUrl: './master.component.html',
  styleUrls: ['./master.component.css']
})
export class MasterComponent {

  bookList : Book[] = [];
  studentPicture : File = null!;

  constructor(
    public dataSvc : DataService,
    private router : Router
  ){}

  bookForm : FormGroup = new FormGroup({
    studentId: new FormControl(undefined, Validators.required),
    studentName: new FormControl(undefined, Validators.required),
    birthDate: new FormControl(undefined),
    phoneNo: new FormControl(undefined, Validators.required),
    maritalStatus: new FormControl(undefined, Validators.required),
    bookItems: new FormArray([])
  });

  get BookItemsArray() {
    return this.bookForm.controls["bookItems"] as FormArray;
  }

  addBookItem() {
    this.BookItemsArray.push(new FormGroup({
      bookId: new FormControl(undefined, Validators.required)
    }));
  }

  removeBookItem(index: number) {
    if (this.BookItemsArray.controls.length > 0)
      this.BookItemsArray.removeAt(index);
  }

  ngOnInit(){
    this.dataSvc.getBookList().subscribe((result) => {
      this.bookList = result;
    });
    this.addBookItem();
  }

  onFileSelected(event : any){
    this.studentPicture = event.target.files[0];
  }

  CreateBook(){

    var formData = new FormData();

    formData.append("booksStringify", JSON.stringify(this.bookForm.get("bookItems")?.value));
    formData.append("studentName", this.bookForm.get("studentName")?.value);
    formData.append("birthDate", this.bookForm.get("birthDate")?.value);
    formData.append("phoneNo", this.bookForm.get("phoneNo")?.value);
    formData.append("maritalStatus", this.bookForm.get("maritalStatus")?.value);
    formData.append("pictureFile", this.studentPicture, this.studentPicture.name);

    this.dataSvc.postBook(formData).subscribe(
      {
        next : r => {
          console.log(r);
          this.router.navigate(['/masterdetails']);
        },
        error : err => {
          console.log(err);
        }
      }  
    );

  }

}
