import { Student } from '../models/student';
import { BookingBook } from '../models/booking-book';  //BookingSpot 
import { Book } from '../models/book';  //Spot
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

const apiUrl = "http://localhost:5117/api/";
@Injectable({
  providedIn: 'root'
})

export class DataService {

  constructor(private http : HttpClient) { }

  getBookList(): Observable<Book[]>{
    return this.http.get<Book[]>(apiUrl + "BookEntries/GetBooks");
  }

  postBook(data : FormData) : Observable<BookingBook>{
    return this.http.post<BookingBook>(apiUrl + "BookEntries", data);
  }

  getStudents(): Observable<Student[]> {  //Client
    return this.http.get<Student[]>(apiUrl + "BookEntries/GetStudents");
  }

  getBookEntries() : Observable<BookingBook[]>{
    return this.http.get<BookingBook[]>(apiUrl + "BookEntries");
  }


}
