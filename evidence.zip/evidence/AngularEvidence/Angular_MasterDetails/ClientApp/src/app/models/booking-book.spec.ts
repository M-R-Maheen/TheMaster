import { BookingBook } from './booking-book';

describe('BookingBook', () => {
  it('should create an instance', () => {
    expect(new BookingBook()).toBeTruthy();
  });
});
