export class Book {
  constructor(
            public bookId? : number,
            public bookName? : string
  ){}
}
