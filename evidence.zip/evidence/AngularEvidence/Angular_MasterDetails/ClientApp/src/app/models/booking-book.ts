import { Book } from "./book";

export class BookingBook {
  constructor(
      public studentId? : number,
      public studentName? : string,
      public birthDate? : Date,
      public phoneNo? : number,
      public picture? : string,
      public pictureFile? : File,
    public maritalStatus?: boolean,
    public bookItems?: Book[]
  ){}
}
