export class Student {
  constructor(
         public studentId? : number,
         public studentName? : string,
         public birthDate? : Date,
         public age? : number,
         public picture? : string,
         public maritalStatus? : boolean
  ){}
}
