﻿using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Angular_MasterDetails.Models
{
    public class Student
    {
        public int StudentId { get; set; }

        public string StudentName { get; set; }

        [Column(TypeName = "date")]
        public DateTime BirthDate { get; set; }

        public int PhoneNo { get; set; }

        public string Picture { get; set; }

        public bool MaritalStatus { get; set; }

        public virtual ICollection<BookEntry> bookEntries { get; set; } = new List<BookEntry>();

    }
    public class Book
    {
        public int BookId { get; set; }
        public string? BookName { get; set; }
        public virtual ICollection<BookEntry> bookEntries { get; set; } = new List<BookEntry>();
    }
    public class BookEntry
    {
        public int BookEntryId { get; set; }

        [ForeignKey("Student")]
        public int StudentId { get; set; }

        [ForeignKey("Book")]
        public int BookId { get; set; }

        //Nav
        public virtual Student Student { get; set; }
        public virtual Book Book { get; set; }
    }
    public class BookDbContext : DbContext
    {
        public BookDbContext(DbContextOptions<BookDbContext> options) : base(options) { }

        public DbSet<Student> Students { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<BookEntry> BookEntries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Book>().HasData
                (
                    new Book { BookId = 1, BookName = "C-Sharp"},
                    new Book { BookId = 2, BookName = "MSSQL"},
                    new Book { BookId = 3, BookName = "Angular Pro"},
                    new Book { BookId = 4, BookName = "SignalR"},
                    new Book { BookId = 5, BookName = "HTML"}
                );
        }

        internal object Find(int studentId)
        {
            throw new NotImplementedException();
        }
    }
}
